/*
SNHU CS499 Project
Author: Tanner Reichard
General setup and folder structure referenced from Codesistency's PERN Stack Course: https://youtu.be/lx3YJj0nJVk?si=uMD9uovO_vBQDqse

*/

import express from "express";
//added for best practice, security middleware that sets up HTTP headers.
import helmet from "helmet";
//added for best practice, logs requests to console.
import morgan from "morgan";
import cors from "cors";
import dotenv from "dotenv";
import path from "path";
import tripsRoutes from "./routes/tripsRoutes.js";
import { sqlConn } from "./config";
//gets .env
dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;
//directory
const __dirname = path.resolve();

//json for extracting data
app.use(express.json());
//adding cors to avoid any cors errors in client.
app.use(cors());
//using helmet and morgan best practices
app.use(helmet());
app.use(morgan("dev"));

//adding trips routes
app.use("/api/trips", tripsRoutes);

//working the backend to display the frontend site if non-api calls are made instead of giving an error
if (process.env.NODE_ENV === "production") {
  const frontendPath = path.join(__dirname, "frontend", "dist");
  app.use(express.static(frontendPath));

    app.get("/*splat", (req, res) => {
    res.sendFile(path.join(frontendPath, "index.html"));
  });
}

async function connectDB(){
    try{
        //SQL query to create trip tables if it don't already exist.
        //Data types revamped from artifact, Neon documentation suggested decimal for currency
        //because of the rounding functionality.
        await sqlConn`
            CREATE TABLE IF NOT EXISTS "tripsData"(
            "tripCode" VARCHAR(255) PRIMARY KEY,
            "startDate" DATE NOT NULL,
            "endDate" DATE NOT NULL,
            "resort" VARCHAR(255) NOT NULL,
            "price" DECIMAL(10,2) NOT NULL
            );
        `;
        console.log("tripsData table created.");
        
        //relocated several variables to secondary table to organize.
        await sqlConn`
            CREATE TABLE IF NOT EXISTS "tripsFormatting"(
            "tripCode" VARCHAR(255) PRIMARY KEY,
            "image" VARCHAR(255) NOT NULL,
            "tripName" VARCHAR (50) NOT NULL,
            "tripDescription" VARCHAR(255) NOT NULL
            );
        `;
        console.log("tripsFormatting table created.");
        
        //creating a view to output the information all at once for site to access.
        //included tripLength using the AGE date difference function in postgre.
        await sqlConn`
            CREATE OR REPLACE VIEW "tripsOutput" AS
            SELECT "tripsData"."tripCode" AS "tripCode",
            "tripsData"."startDate" AS "startDate",
            "tripsData"."endDate" AS "endDate",
            AGE("tripsData"."endDate", "tripsData"."startDate") AS "tripLength",
            "tripsData"."resort" AS "resort",
            "tripsData"."price" AS "price",
            "tripsFormatting"."image" AS "image",
            "tripsFormatting"."tripName" AS "tripName",
            "tripsFormatting"."tripDescription" AS "tripDescription"
            FROM "tripsData"
            INNER JOIN
            "tripsFormatting" ON "tripsData"."tripCode" = "tripsFormatting"."tripCode"
        `
        console.log("tripsOutput view created.")

        //creating the users table for authentication
        await sqlConn`
            CREATE TABLE IF NOT EXISTS "users"(
            id SERIAL PRIMARY KEY,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
            );
        `;
        
        console.log("DB Setup Success.")

    }catch(error){
        console.log("Error Initializing DB", error);
    }
}



//after initializing DB, load port.
connectDB().then(() => {
    app.listen(PORT, () => {
        console.log("Server is running. port " + PORT);
    });
});
