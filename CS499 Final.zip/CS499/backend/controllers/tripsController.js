import { sqlConn } from "../config";
import { arrayToLinkedList, linkedListToArray } from "../utils/LinkedList.js";
import  { sortLinkedList } from "../utils/LinkedListSortingAlgs.js";
//adding bcrypt to secure the password
import bcrypt from 'bcrypt';
//adding json web token for authentication
import jwt from'jsonwebtoken';
//get jwt secret key from .env
import dotenv from 'dotenv';
dotenv.config();

export const getAllTrips = async (req, res) => {
    try{
        //grabbing what field to sort with from dropdown
        const sortField = req.query.sortField || 'startDate';

        const trips = await sqlConn`
            SELECT * FROM "tripsOutput"
        `;

        //convert the SQL rows to a linked list
        const linkedList = arrayToLinkedList(trips);

        //sort the linked list using the merge sort algorithm, with field specified or start date as the default.
        const sortedList = sortLinkedList(linkedList, sortField);

        //reformat the sorted link back to an array for use
        const sortedArray = linkedListToArray(sortedList);


        //this was originally showing just the sortedArray but it became too annoying to sift through the console logs.
        console.log("All products fetched.", sortedArray.length);
        res.status(200).json({success: true, data: sortedArray});
    } catch (error) {
        console.log("getAllTrips error occurred.", error);
        res.status(500).json({success: false, message: "getAllTrips error occurred."});
    }
}

//function for getting a singular trip
export const getTrip = async (req, res) => {
    const { tripCode } = req.params;

    try{
        const trip = await sqlConn`
            SELECT * from "tripsOutput" where "tripCode" = ${ tripCode }
        `
        //success status with tripCode
        res.status(200).json({success: true, data: trip[0]});

    } catch (error){
        console.log("getTrip error occurred.", error);
        res.status(500).json({success: false, message: "getTrip error occurred."});
    }
}

//function for creating a trip
export const createTrip = async (req, res) => {
    const{ tripCode, startDate, endDate, resort, price, image, tripName, tripDescription } = req.body;

    //double check for missing fields.
    if(!tripCode || !startDate || !endDate || !resort || !price || !image || !tripName || !tripDescription){
        return res.status(400).json({success:false, message: "Missing fields."})
    }

    try{
        //calling an insert into the trip data table
        const newTripData = await sqlConn`
            INSERT INTO "tripsData" ("tripCode", "startDate", "endDate", "resort", "price")
            VALUES (${ tripCode }, ${ startDate }, ${ endDate }, ${ resort }, ${ price })
            RETURNING *
        `

        console.log("createTrip tripData success.");

        //calling an insert into the trip formatting table
        const newTripFormatting = await sqlConn`
            INSERT INTO "tripsFormatting" ("tripCode", "image", "tripName", "tripDescription")
            VALUES (${ tripCode }, ${ image }, ${ tripName }, ${ tripDescription })
            RETURNING *
        `

        console.log("createTrip tripData success.");

        //return results for both
        console.log("Trip Added: ", newTripData + " " + newTripFormatting);

        //success status with tripCode
        res.status(201).json({success: true, data: newTripData[0]})

    } catch (error){
        console.log("createTrip error occurred.", error);
        res.status(500).json({success: false, message: "createTrip error occurred."});
    }
};

//function for updating a trip
export const updateTrip = async (req, res) => {
    const { tripCode } = req.params;
    const { startDate, endDate, resort, price, image, tripName, tripDescription } = req.body;

    try{
        const updateTripData = await sqlConn `
        UPDATE "tripsData"
        SET "startDate" = ${ startDate }, "endDate" = ${ endDate }, "resort" = ${ resort }, "price" = ${ price }
        WHERE "tripCode" = ${ tripCode }
        RETURNING * 
        `
        const updateTripFormatting = await sqlConn `
        UPDATE "tripsFormatting"
        SET "image" = ${ image }, "tripName" = ${ tripName }, "tripDescription" = ${ tripDescription }
        WHERE "tripCode" = ${ tripCode }
        RETURNING *
        `

        //double checking if the record was actually found and updated since SQL only 
        //checks if the query ran successfully period, not that it did what we want
        if(updateTripData.length === 0){
            res.status(404).json({success: false, message: "updateTrip error occurred."});
        }
        //return success if it worked.
        res.status(201).json({success: true, data: updateTripData[0]})

    } catch (error){
        console.log("updateTrip error occurred.", error);
        res.status(500).json({success: false, message: "updateTrip error occurred."});
    }
};

//function for registering a user
export const registerUser = async (req, res) => {
    //get email and password
    const { email, password } = req.body;

    //encrypting password with bcrypt, hashed 10 times to meet standards and general best practices
    const hashedPass = await bcrypt.hash(password, 10);

    //add record, returning email and id but not the password
    try{
        const newUser = await sqlConn `
        INSERT INTO "users"
        (email, password) VALUES (${email}, ${hashedPass})
        RETURNING id, email
        `

        res.status(201).json({success: true, data: newUser[0]})

    } catch (error){
        console.log("registerUser error occurred.", error);
        res.status(500).json({success: false, message: "registerUser error occurred."});
    }
};

//function for logging in
export const logInUser = async (req, res) => {
    //get email and password
    const { email, password } = req.body;

    //check if email exists. if it does, compare password to hashed in db.
    try{
        const userExists = await sqlConn `
        SELECT * FROM "users"
        WHERE email = ${email}
        `

        if (!userExists || userExists.length === 0){
            return res.status(404).json({success: false, message: "logInUser error: email does not exist."});
        }

        //assigning the record to a variable for clarity
        const user = userExists[0];

        //validating password using bcrypt
        const validPass = await bcrypt.compare(password, user.password);

        //if password is not good, exit and return error
        if (!validPass) {
            return res.status(401).json({ error: 'Wrong password.' });
        } else {
        //if password is good, assign token
        const token = jwt.sign ({userId: user.email }, process.env.JWT_SECRET, {expiresIn: '1h'});
        return res.status(200).json({ success: true, token });
        }

    } catch (error){
        console.error("registerUser error occurred.", error);
        res.status(500).json({success: false, message: "logInUser error occurred."});
    }
};

//function for token verification, not hooked up to an API but used to gate off functions like creating and edit trips as a security function.
export const verifyToken = (req, res, next) =>{
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) return res.sendStatus(401);

    jwt.verify(token, process.env.JWT_SECRET, (error, user) => {
        if (error) return res.sendStatus(403);
        console.log("USER VERIFIED FROM TOKEN:", user);
        req.user = user;
        next();
    });
};



