import { useTripStore } from "../store/useTripStore.js";

//Setup for the form to register a user. nearly identical to the login modal.
function registerModal(){
    const {authForm, setAuthForm, registerUser, loading}=useTripStore()

    const handleRegisterSubmit = (event) => {
    event.preventDefault();
    registerUser();
    };

    return(

    <dialog id="register_modal">


        <button onClick={() => document.getElementById("register_modal")?.close()}>Close</button>

        
        <h3>Register</h3>

        <form onSubmit={ handleRegisterSubmit }>

            {/* EMAIL */}
            <div>
              <label >Email</label>
              <div>
                <input
                  type="text"
                  placeholder="login@example.edu"
                  value={authForm.email}
                  onChange={(event) => setAuthForm({ ...authForm, email: event.target.value })}
                />
              </div>
            </div>

            {/* PASSWORD */}
            <div>
              <label >Password</label>
              <div>
                <input
                  type="password"
                  placeholder="password"
                  value={authForm.password}
                  onChange={(event) => setAuthForm({ ...authForm, password: event.target.value })}
                />
              </div>
            </div>

            <div>
              {/* preventing the submit button from being clicked if data is missing */}
              <button type="submit" disabled={!authForm.email || !authForm.password || loading}>
                {loading ? (
                  "Loading"
                ): (
                  "Register"
                )}
              </button>

            </div>

        </form>
    </dialog>

    )

}

export default registerModal;