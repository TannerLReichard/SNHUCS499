import { Link } from "react-router-dom";

//getting images from our folder
const images = import.meta.glob('../assets/images/*', {
  eager: true,
  import: 'default',
});

//module for each trip card display
function TripCard({ trip }) {
  const imageSrc = images[`../assets/images/${trip.image}`];

  return (
    <div id="tripCard">
      <img src={imageSrc} alt={trip.tripName} />
      <div id="tripInfo">
        <h2>{trip.tripName}</h2>
        {/*Formatting start, end, and trip length for clarity */}
        <h3>{new Date(trip.startDate).toLocaleDateString()} - {new Date(trip.endDate).toLocaleDateString()} ({trip.tripLength.days} Days)</h3>
        <h3>{trip.resort}</h3>
        <h3>{trip.tripDescription}</h3>
        <h3>${trip.price}</h3>

        {trip.tripCode && (
          <Link to={`/trip/${trip.tripCode}`}>
            <button>Edit Trip</button>
          </Link>
        )}
      </div>

    </div>
  );
}



export default TripCard;