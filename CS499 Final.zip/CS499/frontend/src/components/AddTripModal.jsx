import { useTripStore } from "../store/useTripStore.js";

//Setup for the form to add a trip.
function AddTripModal(){
    const {addTrip, formData, setFormData, loading}=useTripStore()

    return(

            <dialog id="add_trip_modal">

            <form>
              <button>Close</button>
            </form>
        
        <h3>Add New Trip</h3>

        <form onSubmit={addTrip}>

            {/* TRIP CODE */}
            <div>
              <label >Trip Code</label>
              <div>
                <input
                  type="text"
                  placeholder="Trip Code"
                  value={formData.tripCode}
                  onChange={(event) => setFormData({ ...formData, tripCode: event.target.value })}
                />
              </div>
            </div>

            {/* START DATE */}
            <div>
              <label >Start Date</label>
              <div>
                <input
                  type="date"
                  placeholder="Start Date"
                  value={formData.startDate}
                  onChange={(event) => setFormData({ ...formData, startDate: event.target.value })}
                />
              </div>
            </div>

            {/* END DATE */}
            <div>
              <label >End Date</label>
              <div>
                <input
                  type="date"
                  placeholder="End Date"
                  value={formData.endDate}
                  onChange={(event) => setFormData({ ...formData, endDate: event.target.value })}
                />
              </div>
            </div>

            {/* RESORT */}
            <div>
              <label >Resort</label>
              <div>
                <input
                  type="text"
                  placeholder="Resort"
                  value={formData.resort}
                  onChange={(event) => setFormData({ ...formData, resort: event.target.value })}
                />
              </div>
            </div>

            {/* PRICE */}
            <div>
              <label >Price</label>
              <div>
                <input
                  type="text"
                  placeholder="Price"
                  value={formData.price}
                  onChange={(event) => setFormData({ ...formData, price: event.target.value })}
                />
              </div>
            </div>

            {/* IMAGE */}
            <div>
              <label >Image</label>
              <div>
                <input
                  type="text"
                  placeholder="trip1.png, trip2.png, etc."
                  value={formData.image}
                  onChange={(event) => setFormData({ ...formData, image: event.target.value })}
                />
              </div>
            </div>

            {/* TRIP NAME */}
            <div>
              <label >Trip Name</label>
              <div>
                <input
                  type="text"
                  placeholder="Trip Name"
                  value={formData.tripName}
                  onChange={(event) => setFormData({ ...formData, tripName: event.target.value })}
                />
              </div>
            </div>

            {/* TRIP DESCRIPTION */}
            <div>
              <label >Trip Description</label>
              <div>
                <input
                  type="text"
                  placeholder="Trip Description"
                  value={formData.tripDescription}
                  onChange={(event) => setFormData({ ...formData, tripDescription: event.target.value })}
                />
              </div>
            </div>

            <div>
              {/* preventing the submit button from being clicked if data is missing */}
              <button type="submit" disabled={!formData.tripCode || !formData.startDate || !formData.endDate || !formData.resort || !formData.price || !formData.image || !formData.tripName || !formData.tripDescription || loading}>
                {loading ? (
                  "Loading"
                ): (
                  "Add Product"
                )}
              </button>


            </div>


        </form>
    </dialog>

    )

}

export default AddTripModal;