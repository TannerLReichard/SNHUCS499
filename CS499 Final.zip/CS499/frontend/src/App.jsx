import './App.css'
import Navbar from "./components/Navbar.jsx";
import HomePage from './pages/HomePage.jsx';
import TripPage from './pages/TripPage.jsx';
import {Routes, Route, BrowserRouter } from "react-router-dom";

//set up routing for homepage and trip pages
function App() {
  return(
    <BrowserRouter>
      <div id="background">

        <Navbar />

        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/trip/:tripCode" element={<TripPage />} />
        </Routes>

      </div>
    </BrowserRouter>
  );
}

export default App
