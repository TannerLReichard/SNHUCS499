import {create} from 'zustand';
import axios from 'axios';
const BASE_URL = import.meta.env.MODE === "development" ? "http://localhost:1738" : "";

export const useTripStore = create((set,get) => ({
    trips:[],
    loading: false,
    error: null,
    //variable to hold the selected product
    //currentTrip: null,
    //trip form data variables
    formData: {
        tripCode:"",
        startDate:"",
        endDate:"",
        resort:"",
        price:"",
        image:"",
        tripName:"",
        tripDescription:""
    },
    //log in form variables
    authForm: {
        email: "",
        password: "",
    },

    //sets form with initial data
    setFormData: (formData) => set({ formData }),
    //resets form back to blanks
    resetForm: () => set({formData: {tripCode:"", startDate:"", endDate:"", resort:"", price:"", image:"", tripName:"", tripDescription:"" }}),
    //sets auth form with initial data
    setAuthForm: (authForm) => set ({ authForm }),
    //reset auth form back to blanks
    resetAuthForm: () => set({authForm: {email:"", password:""}}),

    addTrip: async(event) => {
        //don't let blanks be accidentally be submitted
        event.preventDefault();

        //get token from local storage
        const token = localStorage.getItem('token');  // <-- get the token here
        //if token doesn't exist, throw error.
        if (!token) {
            throw new Error("No auth token found, log in.");
        }

        //sets loading while action is performed
        set({ loading: true });

        try{
            const { formData } = get();
            //use axios to call our controller url and post our data
            await axios.post(`${BASE_URL}/api/trips`, formData,
                { headers: {Authorization: `Bearer ${token}`}}
            );
            //fetch data again to get everything plus our new trip
            await get().fetchTrips();
            get().resetForm();
            document.getElementById("add_trip_modal").close()
            console.log("Product Added.");
        } catch (error) {
            console.log("Adding product error", error);

        } finally {
            //puts loading away regardless of success or failure
            set({loading: false });
        }

    },

    //getting all trips
    fetchTrips: async(sortField = 'startDate') => {
        //set loading to true while trips is grabbed
        set({loading:true});
        try{

            //get records from our api url. added additional language for sorting algorithm artifact
            const response = await axios.get(`${BASE_URL}/api/trips?sortField=${sortField}`)
            set({trips: response.data.data, error:null})
        } catch (error) {
            set({error: "Error fetching trips"});
        } finally {
            //turn loading off when data is ready
            set({loading:false});
        }
    },

    //fetching just one trip
    fetchTrip: async(tripCode) =>{
        //set loading to true while trips is grabbed
        set({loading:true});
        try{
            //get record from our api url, same as fetchTrips but with tripcode addition
            const response = await axios.get(`${BASE_URL}/api/trips/${tripCode}`)
            set({
            //{currentTrip: response.data.data,
            //set form to existing values
            formData: response.data.data,    
            error:null})
        } catch (error) {
            //if errored, log and set the selected trip to null.
            //set({error: "Error fetching single trip", currentTrip: null});
        } finally {
            //turn loading off when data is ready
            set({loading:false});
        }
    },

    //update trip information
    updateTrip: async (tripCode) => {
        //get token from local storage
        const token = localStorage.getItem('token');  // <-- get the token here
        //if token doesn't exist, throw error.
        if (!token) {
            throw new Error("No auth token found, log in.");
        }
        //set loading to true
        set({loading:true});
        try{
            //get information from the form
            const {formData} = get();
            //use put method to update data in record with authorization token
            const response = await axios.put(`${BASE_URL}/api/trips/${tripCode}`, formData,
                { headers: {Authorization: `Bearer ${token}`}}
            );
            console.log("trip updated:", response.data);
            //set({trips: currentTrip.data.data, error:null})
        } catch (error) {
            console.error("updated failed:", error.response?.data)
        } finally {
            console.log("did this even happen");
            //turn loading off when data is ready
            set({loading:false});
        }
    },

    //registering a user
    registerUser: async () => {
        //set loading to true
        set({loading:true});
        try {
            //get form
            const { authForm } = get();

            //api call with authorization token
            const response = await axios.post(`${BASE_URL}/api/trips/auth/register`, authForm);

            console.log("User registered");

        } catch (error) {
            set({error: "Error registering user"});
        } finally {
            //turn loading off
            set({loading:false});
        }
    },

    //logging a user in
    logInUser: async () => {

        const { authForm } = get();

        //set loading to true
        set({loading:true});
        try {
            const response = await axios.post(`${BASE_URL}/api/trips/auth/login`, authForm);

            //get token from post
            const token = response.data.token;

            // ✅ Save token to localStorage for later use
            localStorage.setItem('token', token);
            //close form
            document.getElementById("log_in_modal")?.close();

            console.log("Logged in.");

            return {success:true};

        } catch (error) {
            set({error: "Error logging in user"});
            return {success: false, message: error};
        } finally {
            //turn loading off
            set({loading:false});
        }
    },

    //simple logout by just removing the token.
    logOutUser: () => {
        localStorage.removeItem('token');
        console.log("Logged out.");
    }

}));