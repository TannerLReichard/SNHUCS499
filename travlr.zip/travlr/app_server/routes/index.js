var express = require('express');
var router = express.Router();
//variable to reference the main.js we just created
const ctrlMain = require('../controllers/main');

/* GET home page. */
//using main.js reference to get new homepage
router.get('/', ctrlMain.index);

module.exports = router;
