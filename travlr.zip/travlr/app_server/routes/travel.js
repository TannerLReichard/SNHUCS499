/* variables to connect travlr controller */
var express = require('express');
var router = express.Router();
var controller = require('../controllers/travel');

/* getting travel page */
router.get('/', controller.travel);

module.exports = router;