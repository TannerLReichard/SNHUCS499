//linked list are best sorted through a merge sort
function sortLinkedList(head, field) {
  //error handling and for the recursive calls, if there's no node or only one node just return it
  if (!head || !head.next) return head;

  //first get the middle of the link
  const middle = getMiddle(head);

  //then get one above the middle, so we can divide the list in half
  const nextToMiddle = middle.next;

  //chopping off the next portion of the middle so the first half of the list ends when the second half starts
  middle.next = null;

  //run this recursively for both halves
  const left = sortLinkedList(head, field);
  const right = sortLinkedList(nextToMiddle, field);

  //return sorted list
  return sortedMerge(left, right, field);
}

//function to get the middle of the list
function getMiddle(head) {
  if (!head) return head;
  let slow = head;
  let fast = head.next;
  //slows move one at a time, fast goes twice as fast. when fast gets to the end, slow will be at the halfway point.
  while (fast && fast.next) {
    slow = slow.next;
    fast = fast.next.next;
  }

  //return slow, the middle point
  return slow;
}

//the sorting of the recursive lists
function sortedMerge(a, b, field) {
  if (!a) return b;
  if (!b) return a;

  //logic to sort decimals as numbers, date fields by date
  const numericFields = ['price', 'tripLength'];
  const dateFields = ['startDate', 'endDate'];

  let valA = a.data[field];
  let valB = b.data[field];

  if (numericFields.includes(field)) {
    valA = parseFloat(valA);
    valB = parseFloat(valB);
  } else if (dateFields.includes(field)){
    valA = new Date(valA);
    valB = new Date(valB);
  }

  let result;

  //evaluate values, recursive call to evaluate the next nodes until list is sorted
  if (valA < valB) {
    result = a;
    result.next = sortedMerge(a.next, b, field);
  } else {
    result = b;
    result.next = sortedMerge(a, b.next, field);
  }

  return result;
}

export { sortLinkedList };
