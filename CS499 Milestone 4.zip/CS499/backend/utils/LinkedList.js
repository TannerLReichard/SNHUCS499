export class Node {
    constructor(data) {
        this.data = data;
        this.next = null;
    }
}

export function arrayToLinkedList(array) {
    //if we have no trips, return null
    if(!array.length) {
        return null;
    }

    //set first trip to the head
    const head = new Node(array[0]);
    let current = head;

    //cycle through rest of the trip list, converting them to slots on the linked list
    for (let counter = 0; counter < array.length - 1; counter++) {
        current.next = new Node(array[counter+1]);
        current = current.next;
    }
    //return head of the list for use
    return head;
}

//opposite function
export function linkedListToArray(head){
    const array = [];
    let current = head;
    //while the list item exists, push it onto the array and go to the next.
    while (current) {
        array.push(current.data);
        current = current.next;
    }

    //return the array
    return array;
}