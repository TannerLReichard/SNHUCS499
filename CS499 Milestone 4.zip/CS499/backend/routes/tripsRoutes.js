import express from "express";
//importing in route function from the controller
import {getAllTrips,getTrip,createTrip,updateTrip, registerUser, logInUser, verifyToken} from "../controllers/tripsController.js";


const router = express.Router();

//routes for authentication
router.post("/auth/register", registerUser);
router.post("/auth/login", logInUser);

//getting routes for full listing, singular trip, creating a trip, and updating one.
router.get("/", getAllTrips);

router.get("/:tripCode", getTrip);

//adding token verification to creating and updating trips so only people logged in can do it.
router.post("/", verifyToken, createTrip);
router.put("/:tripCode", verifyToken, updateTrip);


export default router;
