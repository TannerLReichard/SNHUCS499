import { useEffect, useState } from "react";
import { useTripStore } from "../store/useTripStore.js";
import logo from '../assets/images/logo.png';
function Navbar() {
    const { fetchTrips, registerUser, logOutUser} = useTripStore();
    const [isLoggedIn, setIsLoggedIn] = useState(false);

    //setting up to track if user is logged in to change log in/out appropriately
    useEffect(() => {
        const token = localStorage.getItem("token");
    setIsLoggedIn(!!token);
    }, []);

    // When user logs out, update state too
    const handleLogout = () => {
        logOutUser();
        setIsLoggedIn(false);
    };

    //HTML for the navbar, including the login/out and log out buttons.
    return (
        <nav id="header">
            <img id="logo" src={ logo } alt="LOGO"/>
            <button onClick={() => document.getElementById("add_trip_modal").showModal()}>
                Add Trip
            </button>
            <button onClick={fetchTrips}>Refresh Trips</button>
            {isLoggedIn ? (
                <button onClick={handleLogout}>Log Out</button>
            ) : (
                <button onClick={() => document.getElementById("log_in_modal").showModal()}>Log In</button>
            )}
            <button onClick={() => document.getElementById("register_modal").showModal()}>Register</button>
        </nav>
           
    )
}

export default Navbar