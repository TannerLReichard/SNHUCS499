import { useTripStore } from "../store/useTripStore.js";

//Setup for the form to add a trip.
function logInModal(){
    const {authForm, setAuthForm, logInUser, loading}=useTripStore()

    const handleLoginSubmit = (event) => {
    event.preventDefault();
    logInUser();
    };

    return(

    <dialog id="log_in_modal">


        <button onClick={() => document.getElementById("log_in_modal")?.close()}>Close</button>

        
        <h3>Log In</h3>

        <form onSubmit={ handleLoginSubmit }>

            {/* EMAIL */}
            <div>
              <label >Email</label>
              <div>
                <input
                  type="text"
                  placeholder="login@example.edu"
                  value={authForm.email}
                  onChange={(event) => setAuthForm({ ...authForm, email: event.target.value })}
                />
              </div>
            </div>

            {/* PASSWORD */}
            <div>
              <label >Password</label>
              <div>
                <input
                  type="password"
                  placeholder="password"
                  value={authForm.password}
                  onChange={(event) => setAuthForm({ ...authForm, password: event.target.value })}
                />
              </div>
            </div>

            <div>
              {/* preventing the submit button from being clicked if data is missing */}
              <button type="submit" disabled={!authForm.email || !authForm.password || loading}>
                {loading ? (
                  "Loading"
                ): (
                  "Log In"
                )}
              </button>

            </div>

        </form>
    </dialog>

    )

}

export default logInModal;