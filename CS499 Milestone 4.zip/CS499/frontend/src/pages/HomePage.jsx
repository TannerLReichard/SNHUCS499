import { useEffect, useState } from "react";
import {useTripStore } from "../store/useTripStore.js";
import TripCard from "../components/TripCard";
import AddTripModal from "../components/AddTripModal";
import LogInModal from "../components/logInModal.jsx";
import RegisterModal from "../components/registerModal.jsx";

//setting up homepage, fetching all trips and adding them to the page.
function HomePage(){
    //getting info from the useTripStore to use
    const {trips, loading, error, fetchTrips, logOutUser} = useTripStore();
    //setting up sorting dropdown and having default be the startDate
    const [sortField, setSort] = useState('startDate');

    //call fetchTrips with the selected sort field
    useEffect(() => {
        fetchTrips(sortField)
    }, [sortField])

    return (
        <div>
            <label htmlFor="sortField">Sort by: </label>
            <select
                id="sortField"
                value={sortField}
                onChange={(event) => setSort(event.target.value)}
            >
                <option value="startDate">Start Date</option>
                <option value="endDate">End Date</option>
                <option value="price">Price</option>
            </select>

            <AddTripModal></AddTripModal>
            <LogInModal></LogInModal>
            <RegisterModal></RegisterModal>

            {/*error handling in case a trip can't show up*/}
            {error && <div>{error}</div>}

            {/* displays loading while trip is being fetched*/}
            {loading ? (
                <div> loading... </div>
            ) : (
                <div>
                    {/* maps each of the trips onto the page */}
                    {trips.map((trip) => (
                        <TripCard key = {trip.tripCode} trip={trip} />
                    ))}
                </div>
            )}
        </div>
    )
}
export default HomePage;