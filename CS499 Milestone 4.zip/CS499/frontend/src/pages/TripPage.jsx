import { useTripStore } from "../store/useTripStore";
import { useNavigate, useParams } from "react-router-dom";
import { useEffect } from "react";


function TripPage(){
    const {
        currentTrip,
        formData,
        setFormData,
        loading,
        error,
        fetchTrip,
        updateTrip,
        deleteTrip
    }= useTripStore();

    //getting the tripCode from the url navigated to based on what edit button what pressed
    const navigate = useNavigate();
    const {tripCode} = useParams();

    //fetches the tripCode
    useEffect(() => {
        fetchTrip(tripCode);
    },[fetchTrip, tripCode]);

    //display loading while data loads
    if(loading) {
        return (
            <div>Loading...</div>
        );
    }

    //error handling
    if(error) {
        return(
            <div>{error}</div>
        );
    }

    return(
        
        <div>
            <button onClick={() => navigate("/")}>Back to home</button>

            <h3>Edit Trip</h3>
            {/*call updatetrip with the tripCode, then send them back home */}
            <form onSubmit={async (e) => {
                e.preventDefault();
                await updateTrip(tripCode);
                navigate("/");
            }}>

            {/* TRIP CODE */}
            <div>
              <label >Trip Code</label>
              <div>
                <input
                  type="text"
                  placeholder="Trip Code"
                  value={formData.tripCode}
                  onChange={(event) => setFormData({ ...formData, tripCode: event.target.value })}
                />
              </div>
            </div>

            {/* START DATE */}
            <div>
              <label >Start Date</label>
              <div>
                {/* Grabbing only the date portion of the date field so it populates*/}
                <input
                  type="date"
                  placeholder="Start Date"

                  value={formData.startDate ? formData.startDate.split("T")[0] : ""}
                  onChange={(event) => setFormData({ ...formData, startDate: event.target.value })}
                />
              </div>
            </div>

            {/* END DATE */}
            <div>
              <label >End Date</label>
              <div>
                {/* Grabbing only the date portion of the date field so it populates*/}
                <input
                  type="date"
                  placeholder="End Date"
                  value={formData.endDate ? formData.endDate.split("T")[0] : ""}
                  onChange={(event) => setFormData({ ...formData, endDate: event.target.value })}
                />
              </div>
            </div>

            {/* RESORT */}
            <div>
              <label >Resort</label>
              <div>
                <input
                  type="text"
                  placeholder="Resort"
                  value={formData.resort}
                  onChange={(event) => setFormData({ ...formData, resort: event.target.value })}
                />
              </div>
            </div>

            {/* PRICE */}
            <div>
              <label >Price</label>
              <div>
                <input
                  type="text"
                  placeholder="Price"
                  value={formData.price}
                  onChange={(event) => setFormData({ ...formData, price: event.target.value })}
                />
              </div>
            </div>

            {/* IMAGE */}
            <div>
              <label >Image</label>
              <div>
                <input
                  type="text"
                  placeholder="trip1.png, trip2.png, etc."
                  value={formData.image}
                  onChange={(event) => setFormData({ ...formData, image: event.target.value })}
                />
              </div>
            </div>

            {/* TRIP NAME */}
            <div>
              <label >Trip Name</label>
              <div>
                <input
                  type="text"
                  placeholder="Trip Name"
                  value={formData.tripName}
                  onChange={(event) => setFormData({ ...formData, tripName: event.target.value })}
                />
              </div>
            </div>

            {/* TRIP DESCRIPTION */}
            <div>
              <label >Trip Description</label>
              <div>
                <input
                  type="text"
                  placeholder="Trip Description"
                  value={formData.tripDescription}
                  onChange={(event) => setFormData({ ...formData, tripDescription: event.target.value })}
                />
              </div>
            </div>

            <div>
                {/* Only allow submitting if no fields are missing and loading isn't happening */}
              <button type="submit" disabled={!formData.tripCode || !formData.startDate || !formData.endDate || !formData.resort || !formData.price || !formData.image || !formData.tripName || !formData.tripDescription || loading}>
                {loading ? (
                  "Loading"
                ): (
                  "Edit Product"
                )}
              </button>


            </div>


        </form>

        </div>


    )

}
export default TripPage;